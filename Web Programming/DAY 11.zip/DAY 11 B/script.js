function m(){
    
setInterval(n,500);
}
var x = 0;

function n(){

   

    var v = document.getElementById("d1");
    v.style.marginLeft = x + "px";

    x = x + 100 ;
}

